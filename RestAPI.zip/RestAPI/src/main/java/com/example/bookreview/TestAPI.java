package com.example.bookreview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestAPI {
    public static void main(String[] args) {
        SpringApplication.run(TestAPI.class, args);
    }
}
